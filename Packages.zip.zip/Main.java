public class Main {
    public static void main(String[] args) {

        Customer c = new Customer(
            "C101",
            "Rahul",
            "9876543210"
        );

        Loan l = new Loan(
            "L201",
            "Home Loan",
            500000
        );

        Account a = new Account(
            "A301",
            "Savings",
            20000
        );

        System.out.println("----- CUSTOMER DETAILS -----");
        c.displayCustomer();

        System.out.println("\n----- LOAN DETAILS -----");
        l.displayLoan();

        System.out.println("\n----- ACCOUNT DETAILS -----");
        a.displayBalance();

        System.out.println("\n----- TRANSACTIONS -----");
        a.deposit(10000);
        a.withdraw(5000);

        System.out.println("\n----- UPDATED ACCOUNT DETAILS -----");
        a.displayBalance();
    }
}