public class Account {
    String accountNumber;
    String accountType;
    double balance;

    public Account(String number, String type, double balance) {
        accountNumber = number;
        accountType = type;
        this.balance = balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance = balance + amount;
            System.out.println("Deposited: Rs. " + amount);
        } else {
            System.out.println("Invalid deposit amount");
        }
    }

    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Insufficient Balance");
        } else if (amount <= 0) {
            System.out.println("Invalid withdrawal amount");
        } else {
            balance = balance - amount;
            System.out.println("Withdrawn: Rs. " + amount);
        }
    }

    public void displayBalance() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Type: " + accountType);
        System.out.println("Balance: Rs. " + balance);
    }
}
